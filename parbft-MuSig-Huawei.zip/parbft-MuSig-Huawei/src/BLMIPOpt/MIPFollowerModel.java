package BLMIPOpt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import ilog.concert.IloException;
import ilog.concert.IloLQIntExpr;
import ilog.concert.IloLinearNumExpr;
import ilog.concert.IloNumVar;
import ilog.concert.IloNumVarType;
import ilog.concert.IloQuadIntExpr;
import ilog.concert.IloQuadNumExpr;
import ilog.cplex.IloCplex;

public class MIPFollowerModel {
	
	private static IloCplex cplexModel;
	
	private static Properties config;
	
	private static int nodesNb;
	
	private static int minPeersPerCom;
	
	private static int maxPeersPerCom;
	
	private static int vlID;
	
	private static int leaderNb;
	
	private static double minP2PDelay;
	
	private static double maxP2PDelay;
	
	static double[][] p2pDelays;
	
	// probability of failure of each node
	static double minFailProb;
	static double maxFailProb;
	static double[] failProbs;
	
	static double[] byzFailStatus;
	
	static int byzPeersNb;
	
	static double maxsysFailProb;
	
	static int  fmin;
	
	static double blockSize;
	
	static double blockHeaderSize;
	
	static double blockMetadataSize;
	
	private static String iniConfig_FilePath;
	
	// Decision variables
	//static int[][] LikSol =null;
	static int[][][] XijkSol =null;
	//static int[][][] ZijkSol =null;
	static double[] TSol = null;
	static double[] T1ckSol = null;
	//static double[] DkSol = null;
	public MIPFollowerModel() {
		// TODO Auto-generated constructor stub
		try {
			cplexModel = new IloCplex();
			config = new Properties();
		} catch (IloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void getProperties(String filePath) {
		
		try {
			FileInputStream fis = new FileInputStream(filePath);
			try {
				config.load(fis);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public static void importModelParam(int n, double[][] sysp2pDelays, double[] sysfailProb, double sysFailProb, int sysfmin , double[] sysbyzFailStatus, int sysbyzPeersNb) {
		nodesNb 		= n;
		vlID 			= 1;
		p2pDelays		= sysp2pDelays; 
		failProbs		= sysfailProb;
		maxsysFailProb 	= sysFailProb;
		fmin			= sysfmin;
		byzFailStatus 	= sysbyzFailStatus;
		byzPeersNb		= sysbyzPeersNb;
	}
	

	
	public static void buildModel(int committeeNB, int minPeersPerComl) {
		System.out.println("\n************************************************************ ");
		System.out.println("****** Solving Follower Model for m=" + committeeNB +" *******");
		System.out.println("************************************************************ \n");
		//int m = (int)Math.floor((nodesNb-1)/(3*fmin+1));
		leaderNb = committeeNB;
		System.out.println("Number of committees = " + leaderNb);
		//double x =  (nodesNb-1)/m;
		//System.out.println("nodesNb="+nodesNb+ ", [ (nodesNb-1)/m ]="+ x);
		/*if ( (nodesNb-1) % m == 0.0){
			maxPeersPerCom = (nodesNb-1)/m;
		}
		else {
			maxPeersPerCom = (int)Math.floor((nodesNb-1)/m)+1;
		}*/
		//System.out.println("Maximum number of peers/committee = " + maxPeersPerCom);
		minPeersPerCom = 3*fmin+1;
		if (minPeersPerComl > 0) {
			minPeersPerCom = minPeersPerComl;
		}
		
		System.out.println("Minimum number of peers/committee = " + minPeersPerCom);
		maxPeersPerCom = (nodesNb-1) - (leaderNb-1)*minPeersPerCom;
		System.out.println("Maximum number of peers/committee = " + maxPeersPerCom);
 

		IloNumVar[] T 				= new IloNumVar[3];	
		IloNumVar[]   T1ck 			= new IloNumVar[leaderNb];
		//IloNumVar[][]   Lik   		= new IloNumVar[nodesNb][leaderNb];
		IloNumVar[][][]   Xijk   	= new IloNumVar[nodesNb][nodesNb][leaderNb];
		//IloNumVar[][][]   Zijk   	= new IloNumVar[nodesNb][nodesNb][leaderNb];
		//IloNumVar[]   Dk   			= new IloNumVar[leaderNb];
		
		try {
			for (int id=0; id<3;id++) {
				T[id]		= cplexModel.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, "T"+ (id+1));
				cplexModel.add(T[id]);
			}
			for (int k=0; k<leaderNb;k++) {			
				T1ck[k] 	= cplexModel.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, "T1c"+(k+1));
				cplexModel.add(T1ck[k]);
				//Dk[k]  		= cplexModel.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, "D"+(k+1));
				//cplexModel.add(Dk[k]);
			
			
			
				for (int i=0; i<nodesNb; i++) {
					//Lik[i][k] = cplexModel.numVar(0, 1,IloNumVarType.Bool, "L"+ (i+1) + "_" + (k+1));
					//cplexModel.add(Lik[i][k]);
			
					for (int j=0; j<nodesNb; j++) {
						Xijk[i][j][k] = cplexModel.numVar(0, 1,IloNumVarType.Bool, "X"+ (i+1) + "_" + (j+1) + "_" + (k+1));
						//Zijk[i][j][k] = cplexModel.numVar(0, 1,IloNumVarType.Bool, "Z"+ (i+1) + "_"  + (j+1) + "_" + (k+1));
						cplexModel.add(Xijk[i][j][k]);
						//cplexModel.add(Zijk[i][j][k]);
						//Dijk[i][j] = cplexModel.boolVarArray(nodesNb);
					}
				}
			
			}
			//for (IloNumVar v : Xijk) cplexModel.add(v);
			
			
			// OBJECTIVE FUNCTION
			//cplexModel.getMultiObjInfo(arg0, arg1)

			IloLinearNumExpr obj = cplexModel.linearNumExpr();
			obj.addTerm(2., T[0]);
			obj.addTerm(1., T[1]);
			obj.addTerm(1., T[2]);
			cplexModel.addMinimize(obj);


			// https://www.ibm.com/support/knowledgecenter/SSSA5P_12.7.0/ilog.odms.cplex.help/refjavacplex/html/ilog/concert/IloLinearNumExpr.html
			// https://www.ibm.com/support/knowledgecenter/SSSA5P_12.7.0/ilog.odms.cplex.help/refjavacplex/html/ilog/concert/IloLQNumExpr.html
			// https://www.ibm.com/support/knowledgecenter/SSSA5P_12.7.0/ilog.odms.cplex.help/refjavacplex/html/ilog/concert/IloLQIntExpr.html
			// https://www.ibm.com/support/knowledgecenter/SSSA5P_12.8.0/ilog.odms.cplex.help/refjavacplex/html/ilog/cplex/IloCplex.html
			// https://www.ibm.com/support/knowledgecenter/en/SSSA5P_12.5.0/ilog.odms.ide.help/refjavaopl/html/ilog/concert/IloNumVar.html
			// https://www.ibm.com/support/knowledgecenter/SSSA5P_12.8.0/ilog.odms.cplex.help/refjavacplex/html/ilog/cplex/IloCplex.html#getValue(ilog.concert.IloNumVar)
			
			// https://www.programcreek.com/java-api-examples/?api=ilog.concert.IloNumVar
		
			// CONSTRAINTS
			// Objective constraint 1: k constraints
			IloLinearNumExpr objexpr1 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				objexpr1.addTerm(1., T[0]);
				objexpr1.addTerm(-1., T1ck[k]);
				cplexModel.addGe(objexpr1, 0.0);
				objexpr1.clear();
			}
			

			// Objective constraint 2: k*j constraints
			IloLinearNumExpr objexpr2 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++ ) {				
				for (int i=1; i<nodesNb; i++) {						
					for (int j=1; j<nodesNb; j++) {
						if (j != i) {
							objexpr2.addTerm(1., T1ck[k]);
							objexpr2.addTerm(-p2pDelays[i][j], Xijk[i][j][k]);
							objexpr2.addTerm(-p2pDelays[j][i], Xijk[i][j][k]);
							cplexModel.addGe(objexpr2, 0.0);
							objexpr2.clear();
						}
						}
					}
				}
			// Objective constraint 3: k constraints
			IloLinearNumExpr objexpr3 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {				
				for (int i=1; i<nodesNb; i++) {
					objexpr3.addTerm(1., T[1]);
					objexpr3.addTerm(-p2pDelays[i][0], Xijk[i][0][k]);
					cplexModel.addGe(objexpr3, 0.0);
					objexpr3.clear();
					}
				}
			
			// Objective constraint 4: k constraints
			IloLinearNumExpr objexpr4 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {				
				for (int i=1; i<nodesNb; i++) {
					objexpr4.addTerm(1., T[2]);
					objexpr4.addTerm(-p2pDelays[0][i], Xijk[0][i][k]);
					cplexModel.addGe(objexpr4, 0.0);
					objexpr4.clear();
				}				
			}			
			

		
			// Constraint 1: 1 constraint		
			IloLinearNumExpr expr1 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++ ) {
				for (int i=1; i<nodesNb; i++) {
					expr1.addTerm(1., Xijk[i][i][k]);
				}
				cplexModel.addEq(expr1, 1);
				expr1.clear();
			}
		
			// Constraint 2	: i constraints sum_i (Xiik) <= 1 <==> a peer i could be a leader for only one shard			
			IloLinearNumExpr expr2 = cplexModel.linearNumExpr();
			for (int i=1; i<nodesNb; i++) {
				for (int k=0; k<leaderNb; k++) {
					expr2.addTerm(1.0, Xijk[i][i][k]);
					}
				cplexModel.addLe(expr2, 1.0);
				expr2.clear();
				}

			
			// Constraint 3	: ==> if a peer $i$ is selected as leader for a certain committee, 
			// it cannot be a member of another committee: a peer is either a leader or a member.			
			IloLinearNumExpr expr3 = cplexModel.linearNumExpr();
			for (int i=1; i<nodesNb; i++) {
				for (int k=0; k<leaderNb; k++) {
					expr3.addTerm(1.0, Xijk[i][i][k]);
					for (int j=1; j<nodesNb; j++) {
						if (j != i) {
							expr3.addTerm(1.0, Xijk[j][i][k]);
						}
					}						
				}
				cplexModel.addEq(expr3, 1.0);
				expr3.clear();
			}
	
			
			// Constraint 4	: k*i constraints	==> lower bounds the minimum number of peers per committee
			/*IloLinearNumExpr expr4 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					for (int j=1; j<nodesNb; j++) {
						expr4.addTerm(1., Xijk[i][j][k]);						
						}	
					}
				cplexModel.addGe(expr4, minPeersPerCom);
				expr4.clear();
				}*/
			IloLinearNumExpr expr4 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					expr4.addTerm(-minPeersPerCom, Xijk[i][i][k]);
					for (int j=1; j<nodesNb; j++) {
						expr4.addTerm(1., Xijk[i][j][k]);						
						}
					cplexModel.addGe(expr4, 0.0);
					expr4.clear();
					}

				}

			IloLinearNumExpr expr5 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					expr5.addTerm(-maxPeersPerCom, Xijk[i][i][k]);
					for (int j=1; j<nodesNb; j++) {
						expr5.addTerm(1., Xijk[i][j][k]);						
						}
					cplexModel.addLe(expr5, 0.0);
					expr5.clear();
					}

				}
			
			/*IloQuadNumExpr exprq =cplexModel.quadNumExpr(); //.lqIntExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					for (int j=1; j<nodesNb; j++) {
						exprq.addTerm(-minPeersPerCom, Xijk[i][i][k]);
						exprq.addTerm(1, Xijk[i][i][k], Xijk[i][j][k]); //.addTerm(1., Xijk[i][j][k]);						
						}	
					}
				cplexModel.addGe(exprq, minPeersPerCom);
				exprq.clear();
				}*/
		
			// Constraint 6 : k*i constraints ==> select the most reliable peers to be leaders of committees		
			IloLinearNumExpr expr6 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++ ) {
				for (int i=1; i<nodesNb; i++) {
					expr6.addTerm(failProbs[i], Xijk[i][i][k]);
					cplexModel.addLe(expr6, maxsysFailProb);
					expr6.clear();
				}
			}
			
			// Constraint 7	: distribute byzantine peers into committees		
			IloLinearNumExpr expr7 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					for (int j=1; j<nodesNb; j++) {
						expr7.addTerm(byzFailStatus[j], Xijk[i][j][k]);
					}
				}

				cplexModel.addLe(expr7, Math.ceil(byzPeersNb/(double) leaderNb));
				expr7.clear();
			}
			//System.out.println("ceil: " + Math.ceil(byzPeersNb/(double) leaderNb) + "\t" + (byzPeersNb/(double) leaderNb));		
			// Constraint 6LB	: k*i constraints ==> lower bound of the average delay per committee			
			/*IloLinearNumExpr expr6LB = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					expr6LB.addTerm(maxPeersPerCom, Dk[k]);
					for (int j=1; j<nodesNb; j++) {	
						expr6LB.addTerm(-p2pDelays[i][j], Zijk[i][j][k]);				
						}
					}
				cplexModel.addGe(expr6LB, 0.0);
				expr6LB.clear();
				}*/
			
			// Constraint 6UB	: k*i constraints ==> upper bound of the average delay per committee
			/*IloLinearNumExpr expr6UB = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					expr6UB.addTerm(minPeersPerCom, Dk[k]);
					for (int j=1; j<nodesNb; j++) {	
						expr6UB.addTerm(-p2pDelays[i][j], Zijk[i][j][k]);				
						}
					}
				cplexModel.addLe(expr6UB, 0.0);
				expr6UB.clear();
				}*/
		
				
			// Constraint 8	: Force some variables to be =0				
			/*IloLinearNumExpr expr8 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					expr8.addTerm(1.0, Xijk[i][i][k]);
					}
			}	
			cplexModel.addEq(expr8, 0.0);
			expr8.clear();*/
		
				
			// Constraint 8-1	: ensure connection between leaders and VL Xi1_k = Xii_k	
			IloLinearNumExpr expr81 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					expr81.addTerm(1.0, Xijk[i][0][k]);
					expr81.addTerm(-1.0, Xijk[i][i][k]);
					cplexModel.addEq(expr81, 0.0);
					expr81.clear();
					}
				
			}

				
			// Constraint 8-2	: ensure connection between leaders and VL X1i_k = Xii_k			
			IloLinearNumExpr expr82 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					expr82.addTerm(1.0, Xijk[0][i][k]);
					expr82.addTerm(-1.0, Xijk[i][i][k]);
					cplexModel.addEq(expr82, 0.0);
					expr82.clear();
					}
				
			}
				

			// Constraint 9	: Xijk +XjiK <= 1	for the same k		
			IloLinearNumExpr expr9 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					for (int j=1; j<nodesNb; j++) {
						if(j!=i) {
							expr9.addTerm(1.0, Xijk[i][j][k]);
							expr9.addTerm(1.0, Xijk[j][i][k]);
							cplexModel.addLe(expr9, 1.0);
							expr9.clear();
						}
					}
				}
			}
			
			// Constraint 12	: Xijk +XjiK <= 2			
			/** TO BE VERIFIED !!!!!
			 * IloLinearNumExpr expr12 = cplexModel.linearNumExpr();			
			for (int i=0; i<nodesNb; i++) {
				for (int j=0; j<nodesNb; j++) {
					for (int k=0; k<leaderNb; k++) {
					expr12.addTerm(1.0, Xijk[i][j][k]);
					expr12.addTerm(1.0, Xijk[i][j][k]);
					}
					cplexModel.addLe(expr12, 2.);
					expr12.clear();
				}
			}*/
			

			
			// Constraint 14	:		
			/*IloLinearNumExpr expr14 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					for (int j=1; j<nodesNb; j++) {
						expr14.addTerm(byzFailStatus[j], Xijk[i][j][k]);
					}
				}

				cplexModel.addGe(expr14, 1.0);
				expr14.clear();
			}*/
			
			// Constraint 11	: Xijk +Xjik <= 1			
			/*IloLinearNumExpr expr12 = cplexModel.linearNumExpr();
			
			for (int i=1; i<nodesNb; i++) {
				for (int j=1; j<nodesNb; j++) {
					for (int k=0; k<leaderNb; k++) {
						expr12.addTerm(1.0, Xijk[i][j][k]);
						expr12.addTerm(1.0, Xijk[j][i][k]);
					}
					cplexModel.addLe(expr12, 1.0);
					expr12.clear();
				}
			}*/

				
			// Linearization constraints		
			/*IloLinearNumExpr exprLin1 = cplexModel.linearNumExpr();
			IloLinearNumExpr exprLin2 = cplexModel.linearNumExpr();
			IloLinearNumExpr exprLin3 = cplexModel.linearNumExpr();
			IloLinearNumExpr exprLin4 = cplexModel.linearNumExpr();
			for (int k=0; k<leaderNb; k++) {
				for (int i=1; i<nodesNb; i++) {
					for (int j=1; j<nodesNb; j++) {
						
						exprLin1.addTerm(1., Zijk[i][j][k]);
						exprLin1.addTerm(-1., Xijk[i][j][k]);
						cplexModel.addLe(exprLin1, 0); 
						exprLin1.clear();
						
						exprLin2.addTerm(1., Zijk[i][j][k]);
						cplexModel.addGe(exprLin2, 0);
						exprLin2.clear();
						
						exprLin3.addTerm(1., Zijk[i][j][k]);
						exprLin3.addTerm(-1., Lik[i][k]);
						cplexModel.addLe(exprLin3, 0); 
						exprLin3.clear();
						
						exprLin4.addTerm(1., Zijk[i][j][k]);
						exprLin4.addTerm(-1., Lik[i][k]);
						exprLin4.addTerm(-1., Xijk[i][j][k]);
						cplexModel.addGe(exprLin4, -1); 
						exprLin4.clear();
						}
					}
				}*/
			
			/*cplexModel.solve();
			double[][] LikSol;
			for (int k=0;k<leaderNb;k++) {
				for (int i=0; i<nodesNb;i++) {
					//if (cplexModel.Lik[i][k]>=0.9) {						}
					LikSol[i][k]=cplexModel.getValues(Lik);
					
				}
				
			}*/
			if (cplexModel.solve()) {
				//LikSol = new int[nodesNb][leaderNb];// = cplexModel.getDefaultValue(Lik);
			
				TSol = new double[3];
				T1ckSol =new double[leaderNb];
				//DkSol= new double[leaderNb];
				XijkSol = new int[nodesNb][nodesNb][leaderNb];
				//ZijkSol = new int[nodesNb][nodesNb][leaderNb];
				
				TSol[0]= cplexModel.getValue(T[0]);
				TSol[1]= cplexModel.getValue(T[1]);
				TSol[2]= cplexModel.getValue(T[2]);
				for (int k=0;k<leaderNb;k++) {
					T1ckSol[k]=cplexModel.getValue(T1ck[k]);
					//DkSol[k]=cplexModel.getValue(Dk[k]);
					for (int i=0; i<nodesNb;i++) {
					//if (cplexModel.Lik[i][k]>=0.9) {						}
						//System.out.println("cplexModel.getValue(Lik[i][k])="+cplexModel.getValue(Lik[i][k]));
						//LikSol[i][k]=(int) cplexModel.getValue(Lik[i][k]);
						for (int j=0;j<nodesNb;j++) {
							//System.out.println("cplexModel.getValue(Xijk[i][j][k])="+cplexModel.getValue(Xijk[i][j][k]));
							XijkSol[i][j][k]=(int) cplexModel.getValue(Xijk[i][j][k]);
							//ZijkSol[i][j][k]=(int) cplexModel.getValue(Zijk[i][j][k]);
						}
					
					}
				
				}
			}
			
		} catch (IloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}// end of builModel(...)
	
	// // Solve the Model
	public static boolean solveModel() {
		try {
			// .sav .mps .lp .sav.gz .mps.gz .lp.gz .bz2
			cplexModel.exportModel(System.getProperty("user.dir")+ File.separator +"resources" + File.separator + "FollowerOptModel_"+leaderNb+".lp"); 

		} catch (IloException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		boolean solvingDecision = false;
		try {
			boolean isSolved;
			isSolved = cplexModel.solve();
		
		if(isSolved) {
			solvingDecision = isSolved;
			double objValue =  cplexModel.getObjValue();
			System.out.println("The minimum delay is = " + objValue);	
			System.out.println("T[1] = " + TSol[0]);
			System.out.println("T[2] = " + TSol[1]);
			System.out.println("T[3] = " + TSol[2]);
			
			/*String solFilePath = System.getProperty("user.dir")+ File.separator +"solution.txt";
			try {
				PrintWriter writers = new PrintWriter(solFilePath, "UTF-8");
				
				writers.close();
			}
			catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			
		}
		else {
			System.out.println("Model not solved");
			} 
		
		} catch (IloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return solvingDecision;
	}
	
	public static void write2File(double[][] p2pDelays, double[] failProbs) {
		
		String delaysFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + "delays.txt";
		String failuresFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + "failures.txt";
		try {
			PrintWriter writerd = new PrintWriter(delaysFilePath, "UTF-8");
			PrintWriter writerf = new PrintWriter(failuresFilePath, "UTF-8");
			
			for (int i=0; i<nodesNb; i++) {
				String line_i = "";
				for (int j=0; j<nodesNb; j++) {	
					line_i = line_i + p2pDelays[i][j]+ "\t";
				}
				writerd.write(line_i + "\n");
				writerf.write(i+ "\t"+failProbs[i]+ "\n");
			}
			writerd.close();
			writerf.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//public static void initializeModelParam(String propFilePath, int n,  double[][] sysp2pDelays, double[] sysfailProb, double sysFailProb, int sysfmin, double sysblockSize, double sysblockHeaderSize, double sysblockMetadataSize)
	public static void initializeModelParam(String propFilePath, String initConfigFilePath) {
		
		iniConfig_FilePath  = initConfigFilePath;
		
		getProperties(propFilePath); 			
		/* Number of peers in the system */
		nodesNb = Integer.parseInt(config.getProperty("PeersNumber"))+1;

		vlID = Integer.parseInt(config.getProperty("VLID"));
		
		minP2PDelay = Double.parseDouble(config.getProperty("MinP2PDelay"));
		maxP2PDelay = Double.parseDouble(config.getProperty("MaxP2PDelay"));
		p2pDelays = new double[nodesNb][nodesNb];
		
		minFailProb = Double.parseDouble(config.getProperty("MinFailProb"));
		maxFailProb = Double.parseDouble(config.getProperty("MaxFailProb"));
		failProbs =new double[nodesNb];
		
		// delays initialisation, normally, we should retrieve delays from the running system
		// ===========================================
		/*for (int i=0; i<nodesNb; i++) {
			for (int j=0; j<nodesNb; j++) {	
				//p2pDelays[i][j] = Math.random()*100;
				if (i!=j) {
					p2pDelays[i][j] = Math.random()*(maxP2PDelay-minP2PDelay) + minP2PDelay;
				}
				else{
					p2pDelays[i][j] =0.0;
				}
				//System.out.println("p2pDelays["+i+"]["+j+"]="+p2pDelays[i][j]);
			}
			//failProbs[i]=Math.random();
			failProbs[i]=Math.random()*(maxFailProb-minFailProb) + minFailProb;
			//System.out.println("failProbs["+i+"]="+failProbs[i]);
		}*/
		
		String delaysFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + "delaysA.txt";
		String failuresFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + "failuresA.txt";
		importPeersDelays(delaysFilePath);
		importPeersFailures(failuresFilePath);
		
		//write2File(p2pDelays, failProbs);
		// ===========================================
		
		maxsysFailProb = Double.parseDouble(config.getProperty("MaxSystemFailureProbability"));
		
		fmin = Integer.parseInt(config.getProperty("MinNumberOfFaultyPeersPerCommittee"));
		
		blockSize = Double.parseDouble(config.getProperty("BlockSize"));
		blockHeaderSize = Double.parseDouble(config.getProperty("BlockHeaderSize"));
		blockMetadataSize = Double.parseDouble(config.getProperty("BlockMetadataSize"));
		
	}
	public static void importPeersDelays(String delaysFilePath) {
		
		try {
			
			File filed = new File(delaysFilePath);			
			BufferedReader br = new BufferedReader(new FileReader(filed));

			String line;
			int i = 0;
	        try {
				while((line=br.readLine())!=null)  { 
					String printSTR = "";
					String[] parts = line.split("\t");
					//System.out.println(line + "\n" );
					for (int j=0; j<parts.length; j++) {
						//System.out.println(parts[j].trim() + "\n" );
						p2pDelays[i][j] = Double.parseDouble(parts[j].trim());
						printSTR = printSTR + p2pDelays[i][j] + "\t";
					}
					//System.out.println(printSTR + "\n" );
					i++;
					//line=br.readLine();
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void importPeersFailures(String failuresFilePath) {	
		try {
			
			File filef = new File(failuresFilePath);			
			BufferedReader br = new BufferedReader(new FileReader(filef));

			String line;
			int i = 0;
	        try {
				while((line=br.readLine())!=null)  { 
					String[] parts = line.split("\t");
					failProbs[i] = Double.parseDouble(parts[1].trim());
					//System.out.println(i + "\t" + failProbs[i] + "\n" );
					i++;
					//line=br.readLine();
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static int[][][] getSolutions(){
		return XijkSol;
	}

	/*public static int[][] getLeaders(){
		int[][] Lik = null;
		return Lik;
	}*/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String sep = System.getProperty("file.separator");		
		String propFilePath = System.getProperty("user.dir")+  File.separator + "resources" + File.separator + "config.properties";//C:\Users\b00492594\eclipse-workspace\OptModelling\resources
		//System.out.print(propFilePath);
		String initConfigFilePath = System.getProperty("user.dir")+  sep + "resources" + sep + "iniconfig.txt";
		
	
		MIPFollowerModel fmodel = new MIPFollowerModel();		
		fmodel.initializeModelParam(propFilePath, initConfigFilePath);		
		fmodel.buildModel(2, -1);
		fmodel.solveModel();
		
	}

}
