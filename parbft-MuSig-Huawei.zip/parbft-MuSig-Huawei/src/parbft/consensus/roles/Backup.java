package parbft.consensus.roles;

import parbft.communication.ServerCommunicationSystem;
import parbft.communication.SystemMessage;
import parbft.consensus.Consensus;
import parbft.consensus.Epoch;
import parbft.consensus.messages.*;
import parbft.reconfiguration.ServerViewController;
import parbft.tom.core.ExecutionManager;
import parbft.tom.core.TOMLayer;
import org.bouncycastle.math.ec.ECPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import parbft.tom.util.ECschnorrSig;

import java.math.BigInteger;
import java.util.concurrent.locks.ReentrantLock;


public class Backup {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private int me;
    private ExecutionManager executionManager;
    private MessageFactory factory; // Factory for PaW messages
    private ServerCommunicationSystem communication; // Replicas comunication system
    private TOMLayer tomLayer; // TOM layer
    private ServerViewController controller;
    public ReentrantLock lock = new ReentrantLock();
    public byte[] value;
    BigInteger sk  = null;
    ECPoint pk = null;
    BigInteger k = null;
    ECPoint Q = null;

    public Backup(ServerCommunicationSystem communication, MessageFactory factory, ServerViewController controller) {
        this.communication = communication;
        this.factory = factory;
        this.controller = controller;
        this.sk =  ECschnorrSig.genPrivateKey();
        this.pk = ECschnorrSig.genPublicKey(sk);
    }
    public void setExecutionManager(ExecutionManager executionManager) {
        this.executionManager = executionManager;
    }
    public void setTOMLayer(TOMLayer tomLayer) {
        this.tomLayer = tomLayer;
    }
    public void deliver(SystemMessage msg){
        processMessage(msg);
    }
    public void processMessage(SystemMessage msg){
        if(msg instanceof ConsensusMessage){
            ConsensusMessage consensusMessage = (ConsensusMessage)msg;
            Consensus consensus = executionManager.getConsensus(consensusMessage.getNumber());
            Epoch epoch = consensus.getEpoch(consensusMessage.getEpoch(), controller);

            switch (consensusMessage.getType()){
                case MessageFactory.PREPARE:{
                    PrePrepareReceived(epoch,consensusMessage);
                }break;
                case MessageFactory.COMMIT:{
                    CommitReceived(epoch,consensusMessage);
                }break;
            }
        }
        else if(msg instanceof PrepareStepOneMessage){
            PrepareStepOneMessage stepOneMessage = (PrepareStepOneMessage) msg;
            stepOneReceived(stepOneMessage);
        }
        else if(msg instanceof VerificationMessage){
            VerificationMessage verificationMessage = (VerificationMessage) msg;
            verificationReceived(verificationMessage);
        }
    }
    public void verificationReceived(VerificationMessage verification){
        boolean flag = ECschnorrSig.verify(verification.getMuSigSet(),verification.getValue(),ECschnorrSig.getCurve().decodePoint(verification.getQ()),ECschnorrSig.getCurve().decodePoint(verification.getPk()));
        if(flag){
            communication.send(new int[]{executionManager.getCurrentLeader()},factory.CommitVerification(verification.getProcessId()));
        }
    }

    private void PrePrepareReceived(Epoch epoch, ConsensusMessage msg) {
        lock.lock();
        this.value = msg.getValue();
        if(epoch.propValue == null) {
            epoch.propValue = msg.getValue();
            epoch.propValueHash = tomLayer.computeHash(msg.getValue());
            epoch.getConsensus().addWritten(msg.getValue());
            epoch.deserializedPropValue = tomLayer.checkProposedValue(msg.getValue(), true);
            epoch.getConsensus().getDecision().firstMessageProposed = epoch.deserializedPropValue[0];
        }
        k = ECschnorrSig.genRandomK();
        Q = ECschnorrSig.genCommit(k);
        communication.send(new int[]{executionManager.getCurrentLeader()}, new PrePrepareMessage(Q,pk));
        lock.unlock();
    }
    private void stepOneReceived(PrepareStepOneMessage stepOneMessage){
        lock.lock();
        BigInteger s = ECschnorrSig.genResp(stepOneMessage.getR(), ECschnorrSig.getCurve().decodePoint(stepOneMessage.getQ()), ECschnorrSig.getCurve().decodePoint(stepOneMessage.getPk()), k, sk, value);
        communication.send(new int[]{executionManager.getCurrentLeader()},new SigShareMessage(stepOneMessage.getR(),s,Q,pk));
        lock.unlock();
    }

    private void CommitReceived(Epoch epoch, ConsensusMessage msg) {
        decide(epoch);
    }
    private void decide(Epoch epoch) {
//        dec.setDecisionEpoch(epoch);
        epoch.getConsensus().decided(epoch, true);
    }
}
