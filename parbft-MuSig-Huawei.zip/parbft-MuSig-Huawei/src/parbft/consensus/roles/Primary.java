package parbft.consensus.roles;

import parbft.communication.ServerCommunicationSystem;
import parbft.communication.SystemMessage;
import parbft.consensus.Consensus;
import parbft.consensus.Epoch;
import parbft.consensus.messages.*;
import parbft.reconfiguration.ServerViewController;
import parbft.tom.core.ExecutionManager;
import parbft.tom.core.TOMLayer;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.ECPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import parbft.tom.util.ECschnorrSig;

import javax.crypto.Mac;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;


public class Primary {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private int me; // This replica ID
    private ExecutionManager executionManager; // Execution manager of consensus's executions
    private MessageFactory factory; // Factory for PaW messages
    private ServerCommunicationSystem communication; // Replicas comunication system
    private TOMLayer tomLayer; // TOM layer
    private ServerViewController controller;
    //private Cipher cipher;
    private byte[] value = null;
    private Mac mac;
    public ReentrantLock lock = new ReentrantLock();
    private List<SigShareMessage> sigs = new ArrayList<>();
    private List<PrePrepareMessage> prePrepareList = new ArrayList<>();
    ECPoint pk = null;
    ECPoint Q = null;
    private Epoch epoch;
    private static ECCurve curve;
    private int count=0;
    private int othercount = 0;
    private int C = 0;
    public Primary(ServerCommunicationSystem communication, MessageFactory factory, ServerViewController controller) {
        this.communication = communication;
        this.factory = factory;
        this.controller = controller;
        curve = ECschnorrSig.getCurve();
    }
    public void deliver(SystemMessage msg){
        processMessage(msg);
    }
    public void processMessage(SystemMessage msg){
        if(msg instanceof PrePrepareMessage){
            PrePrepareMessage prepareMessage = (PrePrepareMessage) msg;
            PrePrepareReceived(prepareMessage);
        }else if (msg instanceof SigShareMessage){
            SigShareMessage sigShare = (SigShareMessage) msg;
            SigShareReceived(sigShare);
        }else if (msg instanceof VerificationMessage){
            VerificationMessage verificationMessage = (VerificationMessage) msg;
            verificationReceived(verificationMessage);
        }else if (msg instanceof VerificationCommitMessage){
            VerificationCommitMessage verificationCommitMessage = (VerificationCommitMessage) msg;
            verificationCommitReceived(verificationCommitMessage);
        }
        else if (msg instanceof CommitMessage){

            communication.send(this.controller.getCurrentViewBackups(controller.getStaticConf().getGroup(controller.getStaticConf().getProcessId())), factory.createCommit(epoch.getConsensus().getId(),0,value));

        }

    }
    public void verificationCommitReceived(VerificationCommitMessage msg){
        lock.lock();
        if(msg.getProcessId()==4){
            count++;
            if (count==controller.getCurrentViewN(controller.getStaticConf().getGroup(controller.getStaticConf().getProcessId()))){
                communication.sendToLeader(msg.getProcessId(),new CommitMessage(msg.getProcessId()));
                count=0;
            }
        }else if(msg.getProcessId()==8){
            othercount++;
            if (othercount==controller.getCurrentViewN(controller.getStaticConf().getGroup(controller.getStaticConf().getProcessId()))){
                communication.sendToLeader(msg.getProcessId(),new CommitMessage(msg.getProcessId()));
                othercount=0;
            }
        }else {
            C++;
            if (C==controller.getCurrentViewN(controller.getStaticConf().getGroup(controller.getStaticConf().getProcessId()))){
                communication.sendToLeader(msg.getProcessId(),new CommitMessage(msg.getProcessId()));
                C=0;
            }
        }

        lock.unlock();
    }

    public void verificationReceived(VerificationMessage verification){
        verification.setLeaderMessage(true);
        System.out.println(verification.getProcessId());
        communication.send(controller.getCurrentViewBackups(controller.getStaticConf().getGroup(controller.getStaticConf().getProcessId())),verification);
    }
    public void PrePrepareReceived(PrePrepareMessage prepare){
        lock.lock();
        prePrepareList.add(prepare);
        if (prePrepareList.size()==controller.getCurrentViewN(controller.getStaticConf().getGroup(controller.getStaticConf().getProcessId()))){
            int size = prePrepareList.size();
            for(int i=0;i<size;i++){
                PrePrepareMessage p= prePrepareList.get(i);
                ECPoint PointPK = curve.decodePoint(p.getPk()).normalize();
                ECPoint PointQ = curve.decodePoint(p.getQ()).normalize();
                if(pk==null||Q==null){
                    pk = PointPK;
                    Q = PointQ;
                }else {
                    pk = pk.add(PointPK);
                    Q = Q.add(PointQ);
                }
            }
            BigInteger r = ECschnorrSig.genChal(Q, pk, value);
            communication.send(controller.getCurrentViewBackups(controller.getStaticConf().getGroup(controller.getStaticConf().getProcessId())),new PrepareStepOneMessage(Q,pk,r));
        }
        lock.unlock();
    }
    public void SigShareReceived(SigShareMessage sigShare){
        lock.lock();
        sigs.add(sigShare);
        if (sigs.size()==controller.getCurrentViewN(controller.getStaticConf().getGroup(controller.getStaticConf().getProcessId()))){
            BigInteger s=null;
            for (SigShareMessage sig : sigs) {
                boolean flag = ECschnorrSig.checkResp(sig.getR(), sig.getS(), curve.decodePoint(sig.getQ()), curve.decodePoint(sig.getPk()));
                if(flag){
                    if(s==null)
                        s = sig.getS();
                    else
                        s = s.add(sig.getS());
                }
            }
            BigInteger[] muSigSet = ECschnorrSig.sign(sigShare.getR(), s);
            communication.sendToLeader(0,factory.startVerificationRequest(controller.getStaticConf().getProcessId(),muSigSet, value, Q, pk));

            System.out.println(ECschnorrSig.verify(muSigSet, value, Q, pk));
//                communication.send(this.controller.getCurrentViewBackups(controller.getStaticConf().getGroup(controller.getStaticConf().getProcessId())), factory.createCommit(epoch.getConsensus().getId(),0,value));
            this.reset();
        }
        lock.unlock();
    }

    public void setTOMLayer(TOMLayer tomLayer){
        this.tomLayer = tomLayer;
    }

    public void reset(){
        prePrepareList.clear();
        sigs.clear();
        pk=null;
        Q=null;
    }
    /**
     * startConsensus
     * @param cid
     * @param value
     */
    public void startConsensus(int cid, byte[] value, Consensus consensus) {
        this.value = value;
        ConsensusMessage msg = factory.createPrepare(cid, 0, value);
        epoch = consensus.getEpoch(msg.getEpoch(), controller);
        communication.send(this.controller.getCurrentViewBackups(controller.getStaticConf().getGroup(controller.getStaticConf().getProcessId())), msg);
    }

}
