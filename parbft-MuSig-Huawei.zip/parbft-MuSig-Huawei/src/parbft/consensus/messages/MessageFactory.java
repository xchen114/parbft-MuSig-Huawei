
package parbft.consensus.messages;

import org.bouncycastle.math.ec.ECPoint;

import java.math.BigInteger;

/**
 * This class work as a factory of messages used in the paxos protocol.
 */
public class MessageFactory {

    // constants for messages types
    public static final int PREPARE = 44781;
    public static final int COMMIT = 44788;
//    public static final int WRITE    = 44782;
//    public static final int ACCEPT  = 44783;

    private int from; // Replica ID of the process which sent this message

    /**
     * Creates a message factory
     * @param from Replica ID of the process which sent this message
     */
    public MessageFactory(int from) {
        this.from = from;
    }
    public ConsensusMessage createPrepare(int id, int epoch, byte[] value){
        return new ConsensusMessage(PREPARE, id, epoch, from, value);
    }
    public ConsensusMessage createCommit(int id, int epoch, byte[] value){
        return new ConsensusMessage(COMMIT, id, epoch, from, value);
    }
    public VerificationMessage startVerificationRequest(int processId ,BigInteger[] muSigSet, byte[] value, ECPoint q, ECPoint pk){
        return new VerificationMessage(processId,muSigSet, value,  q,  pk);
    }
    public VerificationCommitMessage CommitVerification(int processId){
        return new VerificationCommitMessage(processId);
    }

}

