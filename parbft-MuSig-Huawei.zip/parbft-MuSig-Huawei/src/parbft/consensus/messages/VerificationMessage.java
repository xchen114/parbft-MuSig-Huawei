package parbft.consensus.messages;

import org.bouncycastle.math.ec.ECPoint;
import parbft.communication.SystemMessage;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.math.BigInteger;
import java.util.Arrays;

public class VerificationMessage extends SystemMessage {
    private BigInteger[] muSigSet;
    private byte[] value= null;
    private byte[] pk = null;
    private byte []Q = null;
    private int processId;
    private boolean isLeaderMessage = false;

    public VerificationMessage() {
    }

    public VerificationMessage(int processId,BigInteger[] muSigSet, byte[] value, ECPoint q, ECPoint pk) {
        this.processId = processId;
        this.muSigSet = muSigSet;
        this.value = value;
        this.Q = q.getEncoded(false);
        this.pk = pk.getEncoded(false);
    }

    public boolean isLeaderMessage() {
        return isLeaderMessage;
    }

    public void setLeaderMessage(boolean leaderMessage) {
        isLeaderMessage = leaderMessage;
    }

    public byte[] getPk() {
        return pk;
    }
    public byte[] getQ() {
        return Q;
    }
    public int getProcessId() {
        return processId;
    }
    public void setProcessId(int group) {
        this.processId = group;
    }
    public BigInteger[] getMuSigSet() {
        return muSigSet;
    }
    public byte[] getValue() {
        return value;
    }
    public void setValue(byte[] value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "VerificationMessage{" +
                "muSigSet=" + Arrays.toString(muSigSet) +
                ", value=" + Arrays.toString(value) +
                ", pk=" + Arrays.toString(pk) +
                ", Q=" + Arrays.toString(Q) +
                ", ProcessId=" + processId +
                '}';
    }
    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeInt(processId);
        out.writeBoolean(isLeaderMessage);
        if(Q == null) {
            out.writeInt(-1);
        } else {
            out.writeInt(Q.length);
            out.write(Q);
        }
        if(pk == null) {
            out.writeInt(-1);
        } else {
            out.writeInt(pk.length);
            out.write(pk);
        }
        if(value == null) {

            out.writeInt(-1);

        } else {

            out.writeInt(value.length);
            out.write(value);

        }

        if(muSigSet==null){
            out.writeInt(-1);
        }else {
            out.writeInt(muSigSet.length);
            for(int i = 0 ;i<muSigSet.length;i++){
                out.writeObject(muSigSet[i]);
            }
        }
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        processId = in.readInt();
        isLeaderMessage = in.readBoolean();
        int toRead = in.readInt();
        if(toRead != -1) {
            Q = new byte[toRead];
            do{
                toRead -= in.read(Q, Q.length-toRead, toRead);
            } while(toRead > 0);
        }
        toRead = in.readInt();
        if(toRead != -1) {
            pk = new byte[toRead];
            do{
                toRead -= in.read(pk, pk.length-toRead, toRead);
            } while(toRead > 0);
        }
        toRead = in.readInt();

        if(toRead != -1) {

            value = new byte[toRead];

            do{

                toRead -= in.read(value, value.length-toRead, toRead);

            } while(toRead > 0);

        }
        toRead = in.readInt();

        if(toRead != -1) {
            muSigSet = new BigInteger[toRead];
            for(int i=0;i<toRead;i++){
                muSigSet[i] = (BigInteger) in.readObject();
            }

        }
    }


}
