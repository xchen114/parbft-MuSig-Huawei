package SPOpt;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map.Entry;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;

import java.util.Properties;
import java.util.Random;

public class FailurerateGeneration {
	
	private static Properties props = new Properties();
	
	private static String Failureratefilename;
	
	private static double minRate;
		
	private static double maxRate;
	
	private static int peersNb;
	
	static double[] Failurerate;

	public static void getProperties(String filePath) {
		
		try {
			FileInputStream fis = new FileInputStream(filePath);
			try {
				props.load(fis);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public static void initialize(String propFilePath) {
		getProperties(propFilePath);
		
		peersNb = Integer.parseInt(props.getProperty("PeersNumber"));
		
		minRate = Double.parseDouble(props.getProperty("MinFailureRate"));
		maxRate = Double.parseDouble(props.getProperty("MaxFailureRate"));
		Failureratefilename = props.getProperty("FailurerateFileName");;
		
		Failurerate = new double[peersNb];
	}
	
	
	public static void generationfailurerate() {
		try {
			FileWriter out = new FileWriter(new File(System.getProperty("user.dir")+ File.separator +"resources" + File.separator  + Failureratefilename + ".txt"));
			for (int i=0; i<peersNb; i++) {
					//p2pDelays[i][j] = Math.random()*100;
					Failurerate[i] = Math.random()*(maxRate-minRate) + minRate;
					out.write(Failurerate[i]+"\t");
					out.write("\r\n");
			}
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		String propFilePath = System.getProperty("user.dir")+ "/resources/config.properties";
		initialize(propFilePath);
		generationfailurerate();
	}

}
