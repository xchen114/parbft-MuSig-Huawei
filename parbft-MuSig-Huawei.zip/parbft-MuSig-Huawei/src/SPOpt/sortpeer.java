package SPOpt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays; 

public class sortpeer {
	
	public static void main(String[] args){
       
        peer[] p = new peer[101];
        failurerate = new double[101];
        
        importFailurerate("/Users/xieyifei/eclipse-workspace/SP_ParBFT/resources/FailureRateA.txt" );
        for (int i=0; i<101; i++) {
        	p[i]=new peer();
        	p[i].fr = failurerate[i];
            p[i].index = i;
            //System.out.println(p[i].fr + "\t" + p[i].index);
        }
        
        for (int i =1; i<101; i++) {
        	for (int j =1; j<101; j++) {
        		peer temp=null;
        		if  (p[i].fr < p[j].fr) {
        			temp=p[i];
        			p[i]=p[j];
        			p[j]=temp;
        		}
        	}
        }
        
        for (int i=1; i<101; i++) {
        	System.out.println(p[i].fr + "\t" + p[i].index);
        }
        
	}
	
	
	static double[] failurerate;
	
	  
	public static void sort() 
    { 
        // Our arr contains 8 elements 
        failurerate = new double[101];
        
        importFailurerate("/Users/xieyifei/eclipse-workspace/SP_ParBFT/resources/FailureRateA.txt" );
        
        for (int i =1; i<101; i++) {
        	for (int j =1; j<101; j++) {
        		double temp=0;
        		if  (failurerate[i] < failurerate[j]) {
        			temp=failurerate[i];
        			failurerate[i]=failurerate[j];
        			failurerate[j]=temp;
        		}
        	}
        }
  
        for (int i=0; i<101; i++) {
        	System.out.println(failurerate[i]);
        }
    } 


	
	public static void importFailurerate(String failurerateFilePath) {
		try {
			
			File filef = new File(failurerateFilePath);			
			BufferedReader br = new BufferedReader(new FileReader(filef));

			String line;
			int i = 0;
	        try {
				while( ((line=br.readLine())!=null) )  { 
					failurerate[i] = Double.parseDouble(line);
					//System.out.println(i + "\t" + failProbs[i] + "\n" );
					System.out.println(failurerate[i] + "\t" + i);
					i++;
					//line=br.readLine();
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
