package SPOpt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import ilog.concert.IloException;
import ilog.concert.IloLQIntExpr;
import ilog.concert.IloLinearNumExpr;
import ilog.concert.IloNumVar;
import ilog.concert.IloNumVarType;
import ilog.concert.IloQuadIntExpr;
import ilog.concert.IloQuadNumExpr;
import ilog.cplex.IloCplex;

public class SPFollowerModel {

	private static IloCplex cplexModel;
	
	private static Properties config;
	
	private static int nodesNb;
	
	private static int minPeersPerCom;
	
	private static int minfollowerpercom;
	
	private static int maxPeersPerCom;
	
	private static int leaderNb;
	
	private static int followerNb;
	
	private static double p2pDelaySD;
	
	private static int scenarioNB;
	
	static double[][] AverageDelays;
	
	static double[][][] spdelay;
	
	static double[][][] p2pDelays;
	
	// probability of failure of each node
	static double minFailProb;
	static double maxFailProb;
	static double[] failurerate;
	
	static double[][] byzFailStatus;
	
	static double[] byzPeersNb;
	
	static double maxsysFailProb;
	
	static int  fmin;
	
	static double blockSize;
	
	static double blockHeaderSize;
	
	static double blockMetadataSize;
	
	private static String iniConfig_FilePath;
	
	static peer[] p = new peer[201];
	
	// Decision variables
	//static int[][] LikSol =null;
	static double  t1 = 0;
	static double  t2 = 0;
	static double  t3 = 0;
	static double  t  = 0;
	static int[][] xijSol =null;
	//static int[][][] ZijkSol =null;
	static double[]   t1csSol = null;
	static double[][] t1cisSol = null;
	//static double[] DkSol = null;
	public SPFollowerModel() {
		// TODO Auto-generated constructor stub
		try {
			cplexModel = new IloCplex();
			config = new Properties();
		} catch (IloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void getProperties(String filePath) {
		
		try {
			FileInputStream fis = new FileInputStream(filePath);
			try {
				config.load(fis);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public static void importModelParam(int n, double[][] sysp2pDelays, double[] sysfailProb,  int sysfmin , double[] sysbyzFailStatus, int sysbyzPeersNb, int S, double SD) {
		nodesNb 		 = n;
		AverageDelays    = sysp2pDelays; 
		failurerate		 = sysfailProb;
		fmin			 = sysfmin;
		scenarioNB       = S;
		p2pDelaySD       = SD;
		initializeSPParam(AverageDelays, p2pDelaySD, scenarioNB);
		sort(failurerate);
		failure("/Users/xieyifei/eclipse-workspace/SP_ParBFT/resources/failures201.txt");
		
	}
	

	
	public static void buildModel(int committeeNB, int minPeersPerComl) {
		System.out.println("\n************************************************************ ");
		System.out.println("****** Solving Follower Model for m=" + committeeNB +" *******");
		System.out.println("************************************************************ \n");
		leaderNb = committeeNB;
		followerNb =  nodesNb - 1 - leaderNb;
		// calculate the number of leader peers and follower peers
		System.out.println("Number of committees = " + leaderNb);
		
		minPeersPerCom = 3*fmin+1;
		minfollowerpercom =  minPeersPerCom-1;
		if (minPeersPerComl > 0) {
			minPeersPerCom = minPeersPerComl;
		}
		// lower bound of follower peers in each committee
		
		System.out.println("Minimum number of peers/committee = " + minPeersPerCom);
		maxPeersPerCom = (nodesNb-1) - (leaderNb-1)*minPeersPerCom;
		System.out.println("Maximum number of peers/committee = " + maxPeersPerCom);
 

		IloNumVar[]     t1cs 			= new IloNumVar[scenarioNB];	
		IloNumVar[][]   t1cis 			= new IloNumVar[leaderNb][scenarioNB];
		IloNumVar[][]   xij  	        = new IloNumVar[leaderNb][followerNb];
		// call cplex api to define the first and second stage variables

		
		try {
			for(int s=0; s< scenarioNB; s++) {
				t1cs[s]		= cplexModel.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, "t1cs");
				cplexModel.add(t1cs[s]);
				
			}
			
			for (int i=0; i<leaderNb;i++) {	
				for(int s=0; s< scenarioNB; s++) {
					t1cis[i][s] 	= cplexModel.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, "t1c"+(i+1));
					cplexModel.add(t1cis[i][s]);
				}
			// define the second stage variables
			

				for (int j=0; j<followerNb; j++) {
					xij[i][j] = cplexModel.numVar(0, 1,IloNumVarType.Bool, "x"+ (i+1) + "_" + (j+1) );
					cplexModel.add(xij[i][j]);
				}
				// define the x_ij as binary variables
			
			
			}


			// Define the objective function and minimize it
			IloLinearNumExpr obj = cplexModel.linearNumExpr();
			for (int s=0; s<scenarioNB; s++) {
				obj.addTerm(1., t1cs[s]);
			}
			cplexModel.addMinimize(obj);
			
		
			// CONSTRAINTS
			// Objective constraint 1: the latency is defined as the maximum latency in the committees
			IloLinearNumExpr objexpr1 = cplexModel.linearNumExpr();
			for (int s=0; s<scenarioNB; s++) {
				for (int i=0; i<leaderNb; i++) {
					objexpr1.addTerm(1., t1cs[s]);
					objexpr1.addTerm(-1., t1cis[i][s]);
					cplexModel.addGe(objexpr1, 0.0);
					objexpr1.clear();
				}
			}
			

			// Objective constraint 2: define the latency in each committee,
			IloLinearNumExpr objexpr2 = cplexModel.linearNumExpr();
			for (int s=0; s<scenarioNB; s++) { 
				for (int i=0; i<leaderNb; i++) {						
					for (int j=0; j<followerNb; j++) {
						objexpr2.addTerm(1., t1cis[i][s]);
						objexpr2.addTerm(-p2pDelays[p[i+1].index][p[j+leaderNb+1].index][s], xij[i][j]);
						objexpr2.addTerm(-p2pDelays[p[j+leaderNb+1].index][p[i+1].index][s], xij[i][j]);
						cplexModel.addGe(objexpr2, 0.0);
						objexpr2.clear();
					}
				}
			}
			
			// Objective constraint 3: k constraints
		
			// Constraint 1: ==> if a peer $i$ is selected as leader for a certain committee, 
			// it cannot be a member of another committee: a peer is either a leader or a member.	
			
			IloLinearNumExpr expr1 = cplexModel.linearNumExpr();
			for (int j=0; j<followerNb; j++ ) {
				for (int i=0; i<leaderNb; i++) {
					expr1.addTerm(1., xij[i][j]);
				}
				cplexModel.addGe(expr1, 1);
				expr1.clear();
			}

			
			// Constraint 2	: The number of peers in each committee should be no less than 3f+1	
			IloLinearNumExpr expr2 = cplexModel.linearNumExpr();
			for (int i=0; i<leaderNb; i++) {
				for (int j=0; j<followerNb; j++) {
					expr2.addTerm(1.0, xij[i][j]);
				}
				cplexModel.addGe(expr2, 3);
				expr2.clear();
			}							

			
			// Constraint 3	: distribute byzantine peers into committees		
			IloLinearNumExpr expr3 = cplexModel.linearNumExpr();
			for (int s=0; s<scenarioNB; s++) {
				for (int i=1; i<leaderNb; i++) {
					for (int j=1; j<followerNb; j++) {
						expr3.addTerm(byzFailStatus[j][s], xij[i][j]);
					}
					cplexModel.addLe(expr3, Math.ceil(byzPeersNb[s]/(double) leaderNb));
					expr3.clear();
				}
			}
			
			// call cplex.solve to solve the model
			if (cplexModel.solve()) {
				//LikSol = new int[nodesNb][leaderNb];// = cplexModel.getDefaultValue(Lik);
			
				t1cisSol =new double[leaderNb][scenarioNB];
				
				xijSol = new int[leaderNb][followerNb];
				
				t1csSol = new double[scenarioNB];
				
				for (int s=0; s<scenarioNB; s++) {
					t1csSol[s]= cplexModel.getValue(t1cs[s]);
				}
				for (int i=0;i<leaderNb;i++) {
					for (int s=0; s<scenarioNB; s++) {
						t1cisSol[i][s]=cplexModel.getValue(t1cis[i][s]);
					}
					for (int j=0;j<followerNb;j++) {
						//System.out.println("cplexModel.getValue(Xijk[i][j][k])="+cplexModel.getValue(Xijk[i][j][k]));
						xijSol[i][j]=(int) cplexModel.getValue(xij[i][j]);
						//ZijkSol[i][j][k]=(int) cplexModel.getValue(Zijk[i][j][k]);
					}
					
				}
				
			}
			
			
		} catch (IloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}// end of builModel(...)
	
	// // Solve the Model
	public static boolean solveModel() {
		try {
			// .sav .mps .lp .sav.gz .mps.gz .lp.gz .bz2
			cplexModel.exportModel(System.getProperty("user.dir")+ File.separator +"lp" + File.separator + "SPFollowerOptModel_"+leaderNb+".lp"); 

		} catch (IloException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		boolean solvingDecision = false;
		try {
			boolean isSolved;
			isSolved = cplexModel.solve();
		
		if(isSolved) {
			solvingDecision = isSolved;
			double objValue =  cplexModel.getObjValue();
			System.out.println("The minimum delay is = " + objValue/scenarioNB);	
			for(int s=0; s<scenarioNB; s++) {
				//System.out.println(TsSol[0][s]);

			}
			t1=0;
			
			for(int s=0; s<scenarioNB; s++) {
				//System.out.println(TsSol[0][s]);
				t1=t1+t1csSol[s];
			}
		
			
			
		} 
		else {
			System.out.println("Model not solved");
			} 
		
		} catch (IloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return solvingDecision;
	}
	
	public static void failure(String failurespath) {
		byzFailStatus = new double [nodesNb][scenarioNB];
		// failure status of peer
		byzPeersNb = new double [scenarioNB];
		// number of byzantine failure peers
		try {
			File filed = new File(failurespath);			
			BufferedReader br = new BufferedReader(new FileReader(filed));

			String line;
			int i = 0;
	        try {
				while((line=br.readLine())!=null && (i<nodesNb))  { 
					String[] parts = line.split("\t");
					for (int j=0; j<8; j++) {
						for (int s=0; s<scenarioNB; s++) {
							if (Double.parseDouble(parts[j]) == s){
								byzFailStatus[i][s] = 1;
								//System.out.println("In scenario " + s + ", peer " + i +  " fails" );
							}
						}
					}
					i++;
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        /*for(int s=0; s<scenarioNB; s++) {
	        	String line1;
	        	int i1 =0;
	        	try {
					while((line1=br.readLine())!=null && (i1<nodesNb)) {
						String[] parts = line1.split("\t");
						for (int j=0; j<8; j++) {
							if (Double.parseDouble(parts[j]) == s){
								byzFailStatus[i1][s] = 1;
								System.out.println("In scenario " + s + ", peer " + i1 +  " fails");
							}
						}
					i1++;
					}
					
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }*/
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(int s=0; s<scenarioNB; s++) {
			for (int i=0; i< nodesNb; i++) {
				byzPeersNb[s] = byzPeersNb[s] + byzFailStatus[i][s];
			}
			//System.out.println("In scenario " + s + ", there are " + byzPeersNb[s] +  " peers fail");
		}
		
	}
	
	
	//Initialize the stochastic parameters, generate scenarios about network delays. By default we use Gaussian distribution. 
	public static void initializeSPParam(double[][] AverageP2PDelays, double p2pDelaySD, int scenarioNB) {
		p2pDelays = new double[nodesNb][nodesNb][scenarioNB];
		// Initialise stochastic delays between every two peers
				int r  = 1230;
				int rr = 95;
				for (int s=0; s<scenarioNB; s++) {
					for (int i=0; i<nodesNb; i++) {
						for (int j=0; j<nodesNb; j++) {	
							//p2pDelays[i][j] = Math.random()*100;
							if (i!=j) {
								double a = AverageP2PDelays[i][j];
								double b = p2pDelaySD;
								java.util.Random random = new java.util.Random();
								random.setSeed(r);
								p2pDelays[i][j][s] = a + b * random.nextGaussian() ;
							}
							else{
								p2pDelays[i][j][s] = 0;
							}
							r=r+rr;
							//System.out.println("p2pDelays["+i+"]["+j+"]="+p2pDelays[i][j]);
						}
					}
				}
	}
	
	// sort the failure rate of peers to select more reliable peers to be leaders
	public static void sort(double[] failruerate) {
        for (int i=0; i<nodesNb; i++) {
        	p[i]=new peer();
        	p[i].fr = failurerate[i];
            p[i].index = i;
            //System.out.println(p[i].fr + "\t" + p[i].index);
        }
        
        for (int i =1; i<nodesNb; i++) {
        	for (int j =1; j<nodesNb; j++) {
        		peer temp=null;
        		if  (p[i].fr < p[j].fr) {
        			temp=p[i];
        			p[i]=p[j];
        			p[j]=temp;
        		}
        	}
        }
        
        /*for (int i=0; i<nodesNb; i++) {
        	System.out.println(p[i].fr + "\t" + p[i].index);
        }*/
	}
	
	// Intialize basic model parameters
	public static void initializeModelParam(String propFilePath ){
		
		//iniConfig_FilePath  = initConfigFilePath;
		
		getProperties(propFilePath); 			
		//Number of peers in the system 
		nodesNb = Integer.parseInt(config.getProperty("PeersNumber"));
		AverageDelays = new double[nodesNb][nodesNb];
		scenarioNB = Integer.parseInt(config.getProperty("NumberOfScenario"));
		p2pDelaySD  = Double.parseDouble(config.getProperty("SDP2PDelay"));
		p2pDelays = new double[nodesNb][nodesNb][scenarioNB];

		p2pDelays = new double[nodesNb][nodesNb][scenarioNB];
		
		minFailProb = Double.parseDouble(config.getProperty("MinFailProb"));
		maxFailProb = Double.parseDouble(config.getProperty("MaxFailProb"));
		failurerate =new double[nodesNb];
		
		String delaysFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + "delaygeneration.txt";
		String failuresFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + "failuresA.txt";
		importPeersDelays(delaysFilePath);
		importfailurerate(failuresFilePath);
		initializeSPParam(AverageDelays, p2pDelaySD, scenarioNB);
		
		// ===========================================
		
		maxsysFailProb = Double.parseDouble(config.getProperty("MaxSystemFailureProbability"));
		
	    fmin = Integer.parseInt(config.getProperty("MinNumberOfFaultyPeersPerCommittee"));
		
		blockSize = Double.parseDouble(config.getProperty("BlockSize"));
		blockHeaderSize = Double.parseDouble(config.getProperty("BlockHeaderSize"));
		blockMetadataSize = Double.parseDouble(config.getProperty("BlockMetadataSize"));
		
	}
	
	// Import peer-to-peer delay files
	public static void importPeersDelays(String delaysFilePath) {
		
		try {
			
			File filed = new File(delaysFilePath);			
			BufferedReader br = new BufferedReader(new FileReader(filed));

			String line;
			int i = 0;
	        try {
				while((line=br.readLine())!=null)  { 
					String printSTR = "";
					String[] parts = line.split("\t");
					//System.out.println(line + "\n" );
					for (int j=0; j<parts.length; j++) {
						//System.out.println(parts[j].trim() + "\n" );
						AverageDelays[i][j] = Double.parseDouble(parts[j].trim());
						printSTR = printSTR + AverageDelays[i][j] + "\t";
					}
					//System.out.println(printSTR + "\n" );
					i++;
					//line=br.readLine();
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	// import failure rate document
	public static void importfailurerate(String failuresFilePath) {	
		try {
			
			File filef = new File(failuresFilePath);			
			BufferedReader br = new BufferedReader(new FileReader(filef));

			String line;
			int i = 0;
	        try {
				while((line=br.readLine())!=null)  { 
					String[] parts = line.split("\t");
					failurerate[i] = Double.parseDouble(parts[1].trim());
					//System.out.println(i + "\t" + failProbs[i] + "\n" );
					i++;
					//line=br.readLine();
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static int[][] getSolutions(){
		return xijSol;
	}

	/*public static int[][] getLeaders(){
		int[][] Lik = null;
		return Lik;
	}*/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String sep = System.getProperty("file.separator");		
		String propFilePath = System.getProperty("user.dir")+  File.separator + "resources" + File.separator + "config.properties";//C:\Users\b00492594\eclipse-workspace\OptModelling\resources
		//System.out.print(propFilePath);
		String initConfigFilePath = System.getProperty("user.dir")+  sep + "resources" + sep + "iniconfig.txt";
		
	
		SPFollowerModel fmodel = new SPFollowerModel();		
		fmodel.initializeModelParam(propFilePath);		
		fmodel.buildModel(2, 1);
		fmodel.solveModel();
	


	}


}
