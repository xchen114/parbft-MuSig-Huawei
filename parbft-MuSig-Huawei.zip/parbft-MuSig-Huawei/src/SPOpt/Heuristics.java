package SPOpt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import ilog.concert.IloException;
import ilog.cplex.IloCplex;

public class Heuristics {
	
	static double[] failurerate;
	
	private static boolean solved;
	
	private static int nodesNb;
	
	private static Properties config;
	
	private static String delaysFile;
	
	private static String failuresFile;
	
	static double[][] AverageP2PDelays;
	
	static double[][] Delay;
	
	private static int leaderNb;
	
	private static int followerNb;
	
	private static int maxLNb;
	
	private static double maxcapacity;
	
	private static double requiredcapacity;
	
	private static int fmin;
	
	private static int [] allocate;
	
	private static int maxPeersPerCom;
	
	private static int [] PeersofCom;
	
	
	private static String iniConfig_FilePath;
	
	static Map<Integer, String> ID2IP = new HashMap<Integer, String>();
	
	
	
	public static void initializepara(String propFilePath, String initConfigFilePath) {
		config = new Properties();
		iniConfig_FilePath  = initConfigFilePath;
		getProperties(propFilePath); 			
		readConfig();
		
		System.out.println("ID2IP.size(): " + ID2IP.size());
		nodesNb = ID2IP.size();
		
		delaysFile = config.getProperty("DelaysFileName");
		failuresFile=config.getProperty("FailurerateFileName");
		String delaysFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + delaysFile+ ".txt";
		String failuresFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + failuresFile + ".txt";
		
		AverageP2PDelays = new double[nodesNb][nodesNb];
		failurerate = new double[nodesNb];
		Delay = new double[nodesNb][nodesNb];
		
		solved=true;
		
		requiredcapacity = 1;
		
		maxcapacity = 100000;
		
		fmin = Integer.parseInt(config.getProperty("MinNumberOfFaultyPeersPerCommittee"));
		
		leaderNb=(int) Math.min(Math.floor(maxcapacity/requiredcapacity),Math.floor((nodesNb-1)/(3*fmin+1)));
		
		maxPeersPerCom=nodesNb-1-(3*fmin+1)*(leaderNb-1);
		
		followerNb= nodesNb-1-leaderNb;
		
		allocate = new int[followerNb];
		
		PeersofCom =  new int[leaderNb];
		
		System.out.println(leaderNb);
		System.out.println(followerNb);
		System.out.println(maxPeersPerCom);
		
		importPeersDelays(delaysFilePath);
		importFailurerate(failuresFilePath);
		sort(failurerate);
	}
	
	static peer[] p = new peer[10001];
	
	public static void getProperties(String filePath) {
		
		try {
			FileInputStream fis = new FileInputStream(filePath);
			try {
				config.load(fis);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public static void readConfig() {
		try {
			
			File file = new File(iniConfig_FilePath);			
			BufferedReader br = new BufferedReader(new FileReader(file));

			String line;
			int i = 0;
			// VL has ID = 1
			int id = 0;//2;
	        try {
				while((line=br.readLine())!=null && !line.contains("###"))  { 
					// @<127.0.0.1:22000>=[2,CL]#
					String ip =  line.substring(line.indexOf("@")+1, line.indexOf("="));
                    String attr = line.substring(line.indexOf("=")+1, line.indexOf("#"));
                    String idStr = line.substring(line.indexOf("#")+1, line.indexOf("%"));
					String[] parts = attr.split(",");
                    if (parts[1].contains("VL")) {
                    	ID2IP.put(1,ip);
                    }
                    else {
                    	id = Integer.parseInt(idStr);
                    	ID2IP.put(id,ip);
                    }
					
					i++;
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void importPeersDelays(String delaysFilePath) {
		
		try {
			
			File filed = new File(delaysFilePath);			
			BufferedReader br = new BufferedReader(new FileReader(filed));

			String line;
			int i = 0;
	        try {
				while((line=br.readLine())!=null && (i<nodesNb))  { 
					//String printSTR = "";
					String[] parts = line.split("\t");
					//System.out.println(line + "\n" );
					for (int j=0; j<nodesNb; j++) {
						//System.out.println(parts[j].trim() + "\n" );
						AverageP2PDelays[i][j] = Double.parseDouble(parts[j]);
						//printSTR = printSTR + p2pDelays[i][j] + "\t";
					}
					//System.out.println(printSTR + "\n" );
					i++;
					//line=br.readLine();
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void importFailurerate(String failurerateFilePath) {
		try {
			
			File filef = new File(failurerateFilePath);			
			BufferedReader br = new BufferedReader(new FileReader(filef));

			String line;
			int i = 0;
	        try {
				while( ((line=br.readLine())!=null) && (i< nodesNb))  { 
					failurerate[i] = Double.parseDouble(line);
					//System.out.println(i + "\t" + failProbs[i] + "\n" );
					//System.out.println(failurerate[i] + "\t" + i);
					i++;
					//line=br.readLine();
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void sort(double[] failruerate) {
		//importfailurerate("/Users/xieyifei/eclipse-workspace/SP_ParBFT/resources/FailureRateA.txt" );
        for (int i=0; i<nodesNb; i++) {
        	p[i]=new peer();
        	p[i].fr = failurerate[i];
            p[i].index = i;
            //System.out.println(p[i].fr + "\t" + p[i].index);
        }
        
        for (int i =1; i<nodesNb; i++) {
        	for (int j =1; j<nodesNb; j++) {
        		peer temp=null;
        		if  (p[i].fr < p[j].fr) {
        			temp=p[i];
        			p[i]=p[j];
        			p[j]=temp;
        		}
        	}
        }
        
        /*for (int i=0; i<nodesNb; i++) {
        	System.out.println(p[i].fr + "\t" + p[i].index);
        }*/
	}
	
	public static void greedy() {
		
		for (int i=0; i<leaderNb; i++) {
			for (int j=0; j< followerNb; j++) {
				Delay[i][j]= AverageP2PDelays[p[i+1].index][p[j+leaderNb+1].index] + AverageP2PDelays[p[j+leaderNb+1].index][p[i+1].index];
				//System.out.println(Delay[i][j]);
			}
		}
		
		
		for (int j=0; j< followerNb; j++) {
			allocate[j]=0;
			PeersofCom[0]=followerNb;
		}
		
		for (int i=1; i<leaderNb; i++) {
			PeersofCom[i]=0;
		}
		
		for (int j=0; j<followerNb; j++) {
			for (int i=1; i< leaderNb; i++) {
				if(Delay[i][j]<Delay[allocate[j]][j] && PeersofCom[i]< maxPeersPerCom-1) {
					// compare the delay between the leader with other peers
					PeersofCom[allocate[j]]= PeersofCom[allocate[j]]-1;
					allocate[j]=i;
					PeersofCom[i]=PeersofCom[i]+1;
				}
			}
			/*for (int i=0; i<leaderNb; i++) {
				if (PeersofCom[i] > maxPeersPerCom) {
					
				}
			}*/
		}
	}
	
	public static void writeConfig() {
		// iniConfig_FilePath
		String FilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator  +  "heuristicssolution.txt";// "intConfigOpt.txt";
		
		if (solved) {
			
			try {
				PrintWriter writerf = new PrintWriter(FilePath, "UTF-8");
				
				String line_i = "";
				
				
				writerf.write("@" + ID2IP.get(1) + "=[0,VL]#\n");
				
				for (int i=0; i<leaderNb; i++) {
					line_i = "@" + ID2IP.get(p[i+1].index+1) + "=[" + (i+1) + ",CL]#\n"; 
					writerf.write(line_i);
					for(int j=0; j< followerNb; j++) {
						if (allocate[j] == i) {
							line_i = "@" + ID2IP.get(p[j+1+leaderNb].index+1) + "=[" + (i+1) + ",CF]#\n"; 
							writerf.write(line_i);
						}
					}
					/*if(i==0) {
						writerf.write("###");
						writerf.write("\r\n");
						writerf.write("\r\n");
					}*/
				}
				writerf.close();
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else {
			System.out.println("*initconfig* file is not updated because optimisation problem is not solved!");
		}
		
	}
	
	public static void printSolutions() {
		System.out.println("\n==========================================" );
		System.out.println("========= Leader Problem Logging =========" );
		System.out.println("==========================================\n" );
		if (solved) {
			System.out.println("The minimal objective function: " + " is obtained with "+ leaderNb + " committees.\n" );
			System.out.println("The Committees Leaders are:\n");
			
				for (int i=0; i<leaderNb;i++) {
					//if (optLik[i][k]>=0.999) {	System.out.println("Lik["+i+"]["+k+"]="+optLik[i][k]);
						System.out.println("In the committee" + (i+1) + ", there are " + PeersofCom[i]  + " peers.");
						for (int j=0; j<followerNb;j++) {
							if ( allocate[j] == i ) {
								System.out.println("peer" + (p[i+1].index+1) + " is the leader of peer" + (p[j+1+leaderNb].index+1));
							}
						
						}
					//}	
				}
			
		}
		else {
			System.out.println("No solutions to print!");
		}
	}
	
	public static void main(String[] args) {
		String sep = System.getProperty("file.separator");		
		iniConfig_FilePath = System.getProperty("user.dir")+  sep + "resources" + sep + "iniconfig.txt";

		String propFilePath = System.getProperty("user.dir")+  File.separator + "resources" + File.separator + "config.properties";
		long startTime=System.currentTimeMillis();
		initializepara(propFilePath, iniConfig_FilePath);
		greedy();
		//printSolutions();
		writeConfig();
		long endTime=System.currentTimeMillis();
		float excTime=(float)(endTime-startTime)/1000;
		// compute excution time
	    System.out.println("excution time = "+excTime+"s");
	}
}
