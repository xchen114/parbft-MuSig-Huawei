package SPOpt;

public class peer {
	double fr;
	int    index;
}
