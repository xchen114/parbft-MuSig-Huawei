package SPOpt;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map.Entry;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;

import java.util.Properties;
import java.util.Random;

public class DelayGeneration {

	private static Properties props = new Properties();
	
	private static double minDelay;
		
	private static double maxDelay;
	
	private static int peersNb;
	
	static byte[][] AverageDelays;
	
	static double[][] arr;
	

	public static void getProperties(String filePath) {
		
		try {
			FileInputStream fis = new FileInputStream(filePath);
			try {
				props.load(fis);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public static void initialize(String propFilePath) {
		getProperties(propFilePath);
		
		peersNb = Integer.parseInt(props.getProperty("PeersNumber"));
		
		minDelay = Double.parseDouble(props.getProperty("MinP2PDelay"));
		maxDelay = Double.parseDouble(props.getProperty("MaxP2PDelay"));
		
		AverageDelays = new byte[peersNb][peersNb];
	}
	
	public static void generation() {
		try {
			FileWriter out = new FileWriter(new File(System.getProperty("user.dir")+ File.separator +"resources" + File.separator  + "delay100001" + ".txt"));
			for (int i=0; i<peersNb; i++) {
				for (int j=0; j<peersNb; j++) {	
					//p2pDelays[i][j] = Math.random()*100;
					if (i!=j) {
						AverageDelays[i][j]= (byte) (Math.random()*(maxDelay-minDelay) + minDelay);
						//System.out.println(AverageDelays[i][j]);
						out.write(AverageDelays[i][j]+"\t");
						//out.write("\r\n");
					}
					else{
						AverageDelays[i][j] =0;
						//System.out.println(0);
						out.write(AverageDelays[i][j]+"\t");
						//out.write("\r\n");
					}
				}
				out.write("\r\n");
			}
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public static void main(String[] args) {
		String propFilePath = System.getProperty("user.dir")+ "/resources/config.properties";
		initialize(propFilePath);
		generation();
		//read(System.getProperty("user.dir")+ File.separator +"resources" + File.separator  + "delay5.txt");
	}

}
