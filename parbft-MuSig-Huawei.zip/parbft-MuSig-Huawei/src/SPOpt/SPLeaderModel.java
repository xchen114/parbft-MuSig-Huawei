package SPOpt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import ilog.concert.IloException;
import ilog.cplex.IloCplex;

public class SPLeaderModel {
	
	private static IloCplex cplexModel;
	
	private static boolean solved;
	
	private static double optimalObjFunc;
	
	private static int [][] optxij;
	
	private static int optm;
	
	private static Properties config;
	
	private static boolean isRandom;
	
	private static int nodesNb; 
	
	private static int minPeersPerCom;
	
	private static int maxPeersPerCom;
	
	private static int vlID;
	
	private static int vlCapacity;
	
	private static int leaderNb;
	
	private static int followerNb;
	
	private static int maxLNb;
	
	static peer[] p = new peer[201];
	
	private static double p2pDelaySD;
	
	private static int scenarioNB;
	
	static double[][] AverageP2PDelays;
	
	
	static double[][][] p2pDelays;
	
	static double  t1 = 0;
	static double  t2 = 0;
	static double  t3 = 0;
	static double  t  = 0;
	
	static double t2M;
	static double t3M;
	
	static double[]  t1s;
	static double[]  t2s;
	static double[]  t3s;
	static double[]  ts;
	
	// probability of failure of each node
	static double minFailProb;
	static double maxFailProb;
	
	static double[] failurerate;
	static double[] failProbs;
	
	static double[] byzFailStatus;
	
	static double[] capacity;
	
	static double maxsysFailProb;
	
	static int  fmin;
	
	static double byzFailTh;
	
	static int byzPeersNb;
	
	static double blockSize;
	
	static double blockHeaderSize;
	
	static double blockMetadataSize;
	
	private static String delaysFile;
	
	private static String failuresFile;
	
	private static String capacityfile;
	
	private static String iniConfig_FilePath;
	
	private static String SPoutputFileName;
	
	static Map<Integer, String> ID2IP = new HashMap<Integer, String>();
	
	
	// Decision variables
	//static int[][] LikSol =null;
	//static int[][][] Xijk =null;
	//static int[][][] ZijkSol =null;
	//static double[] TSol = null;
	//static double[] T1ckSol = null;
	//static double[] DkSol = null;
	

	public SPLeaderModel() {
		// TODO Auto-generated constructor stub
		try {
			cplexModel = new IloCplex();
			solved = false;
			optxij = null;
			optimalObjFunc = Double.MAX_VALUE ;
			config = new Properties();
		} catch (IloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void getProperties(String filePath) {
		
		try {
			FileInputStream fis = new FileInputStream(filePath);
			try {
				config.load(fis);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	//public static void initializeModelParam(String propFilePath, int n,  double[][] sysp2pDelays, double[] sysfailProb, double sysFailProb, int sysfmin, double sysblockSize, double sysblockHeaderSize, double sysblockMetadataSize)
	public static void initializeModelParam(String propFilePath, String initConfigFilePath) {
		
		iniConfig_FilePath  = initConfigFilePath;
		getProperties(propFilePath); 			
		readConfig();
			/*for (int i : ID2IP.keySet()) {
				 System.out.println("key: " + i + " value: " + ID2IP.get(i));
			}*/
			
		System.out.println("ID2IP.size(): " + ID2IP.size());
		nodesNb = ID2IP.size();
		//}
		/*else {
			nodesNb = Integer.parseInt(config.getProperty("PeersNumber"))+1;
			for (int i = 1; i<=nodesNb; i++) {
				ID2IP.put(i, "ip"+i);
			}
		}*/
		

		AverageP2PDelays = new double[nodesNb][nodesNb];
		//p2pDelays = new double [nodesNb][nodesNb][scenarioNB];
		
		minFailProb = Double.parseDouble(config.getProperty("MinFailProb"));
		maxFailProb = Double.parseDouble(config.getProperty("MaxFailProb"));
		failProbs =new double[nodesNb];
		failurerate = new double[nodesNb];
		byzFailStatus=new double[nodesNb];
		byzPeersNb = 0;

		System.out.println("Number of peers: " + nodesNb);

		vlID = Integer.parseInt(config.getProperty("VLID"));
		
		scenarioNB = Integer.parseInt(config.getProperty("NumberOfScenario"));
		
		capacity = new double[scenarioNB];
		
		p2pDelaySD = Double.parseDouble(config.getProperty("SDP2PDelay"));
		
		vlCapacity = Integer.parseInt(config.getProperty("VLCapacity"));

		maxsysFailProb = Double.parseDouble(config.getProperty("MaxSystemFailureProbability"));
		
		fmin = Integer.parseInt(config.getProperty("MinNumberOfFaultyPeersPerCommittee"));
		
		byzFailTh = Double.parseDouble(config.getProperty("ByzantineFaultProbabilityThreshold"));
		
		blockSize = Double.parseDouble(config.getProperty("BlockSize"));
		blockHeaderSize = Double.parseDouble(config.getProperty("BlockHeaderSize"));
		blockMetadataSize = Double.parseDouble(config.getProperty("BlockMetadataSize"));
		
		SPoutputFileName = config.getProperty("SPOutputFileName");
		
		
		delaysFile = config.getProperty("DelaysFileName");
		failuresFile=config.getProperty("FailurerateFileName");
		capacityfile=config.getProperty("capacityfilename");
		String delaysFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + delaysFile+ ".txt";
		String failuresFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + failuresFile + ".txt";
		String capacityfilepath = System.getProperty("user.dir")+ File.separator + "resources"+ File.separator + capacityfile + ".txt";
		importPeersDelays(delaysFilePath);
		importFailurerate(failuresFilePath);
		sort(failurerate);
		importcapacities(capacityfilepath);
		//importPeersFailures(failuresFilePath);
		
	}
	
	// build leader model to optimally solve the number of committees
	public static void buildModel() {
		minPeersPerCom = 3*fmin+1;
		System.out.println("Minimum number of peers/committee = " + minPeersPerCom);
		//leaderNb = nodesNb-1;
		int maxCommittes = Math.abs((nodesNb-1)/(minPeersPerCom));
		System.out.println("maxCommittes= " + maxCommittes + "\tvlCapacity="+vlCapacity);
		maxLNb = Math.min(maxCommittes, vlCapacity) ;
		System.out.println("Maximum number of leaders= " + maxLNb); 
	}
	
	// solve the leader model
	public static void solveProblem() {
		String sep = System.getProperty("file.separator");		
		String propFilePath = System.getProperty("user.dir")+  File.separator + "resources" + File.separator + "config.properties";
		String initConfigFilePath = System.getProperty("user.dir")+  sep + "resources" + sep + "iniconfig.txt";
		
		// generate stochastic delays with scenarios
		p2pDelays = new double [nodesNb][nodesNb][scenarioNB];
		int r  = 1230;
		int rr = 95;
		for (int s=0; s<scenarioNB; s++) {
			for (int i=0; i<nodesNb; i++) {
				for (int j=0; j<nodesNb; j++) {	
					//p2pDelays[i][j] = Math.random()*100;
					if (i!=j) {
						double a = AverageP2PDelays[i][j];
						double b = p2pDelaySD;
						java.util.Random random = new java.util.Random();
						random.setSeed(r);
						p2pDelays[i][j][s] = a + b * random.nextGaussian() ;
					}
					else{
						p2pDelays[i][j][s] = 0;
					}
					r=r+rr;
					//System.out.println("p2pDelays["+i+"]["+j+"]="+p2pDelays[i][j]);
				}
			}
		}
		
		int iter = 0;
		int maxIter = 0;
		if (nodesNb-1 > 3*byzPeersNb+1) {
		
			//for (int m=1; m<=maxLNb ; m++) {
			//SPFollowerModel lModel = new SPFollowerModel();
			
			//lModel.importModelParam(nodesNb, AverageP2PDelays, failProbs, maxsysFailProb, fmin, byzFailStatus, byzPeersNb, scenarioNB, p2pDelaySD);
			
			// first solve the model started with the largest number of committees, then compare with the solution with next iterations of different number of committees. 
			for (int m=maxLNb; m>=1 ; m--) {
				
				t2M=0;
				t3M=0;
				
				for (int i=0; i<m; i++) {
					t2M=t2M + AverageP2PDelays[p[i+1].index][0];
				}
				
				for (int i=0; i<m; i++) {
					t3M=t3M + AverageP2PDelays[0][p[i+1].index];
				}
				t2M=t2M/m;
				t3M=t3M/m;
				System.out.println(t2M + ", " + t3M);
				
				// Build follower model to optimally solve the allocation of peers given the number of committees
				SPFollowerModel lModel = new SPFollowerModel();
				lModel.importModelParam(nodesNb, AverageP2PDelays, failurerate, fmin, byzFailStatus, byzPeersNb, scenarioNB, p2pDelaySD);
				lModel.buildModel(m, minPeersPerCom);
				
				if(lModel.solveModel()) {
					int [][] xij = new int[m][nodesNb-1-m];
					//int [][] Lik = new int[nodesNb][m];
					double ObjFunc = 0.0;
					xij= lModel.getSolutions();
					
					/*double [] t1s = new double[scenarioNB];
					double [] t2s = new double[scenarioNB];
					double [] t3s = new double[scenarioNB];*/
					double [] ts  = new double[scenarioNB];
					t=0;
					
					for(int s =0; s < scenarioNB; s++) {
						for (int i=0; i <m; i++) {
							for(int j=0; j<nodesNb-m-1; j++) {
								if(xij[i][j]>=0.9) {
									t1=Math.max(t1, p2pDelays[p[i+1].index][p[j+1+m].index][s]+p2pDelays[p[j+1+m].index][p[i+1].index][s]);
									t2=Math.max(t2, p2pDelays[p[i+1].index][0][s]);
									t3=Math.max(t3, p2pDelays[0][p[i+1].index][s]);
								}
							}
						}
						ts[s] = 2*t1 + t2 + t3;
						if (capacity[s]<m) {
							ts[s]=ts[s]+t2M+t3M;
						}
						t=t+ts[s];
					}
					t = t/scenarioNB; 
					
					/*for (int i=0; i <m; i++) {
						for(int j=0; j<nodesNb-m-1; j++) {
							if(xij[i][j]>=0.9) {
								t1=Math.max(t1, AverageP2PDelays[p[i+1].index][p[j+1+m].index]+AverageP2PDelays[p[j+1+m].index][p[i+1].index]);
								t2=Math.max(t2, AverageP2PDelays[p[i+1].index][0]);
								t3=Math.max(t3, AverageP2PDelays[0][p[i+1].index]);
							}
						}
					}
					t=2*t1+t2+t3;*/
					System.out.println(t);
					ObjFunc = Math.max(ObjFunc, t);
					//Lik = lModel.getLeaders();
					
					System.out.println("ObjFunc="+ObjFunc + "\toptimalObjFunc="+optimalObjFunc);
					//System.out.println("t1hhh=" + t1);
					if (ObjFunc < optimalObjFunc) {
						optimalObjFunc = ObjFunc;
						optxij = xij;
						//optLik = Lik;
						optm = m;
						solved=true;
					}
					else {
						iter++;
					}
					if (iter >=maxIter) {
						System.out.println("Objective Function is increasing for "+maxIter+" time: algorithm stopped!");
						break;
					}
					// After winning "maxiter" comparison, then the optimal number of committees and its corresponding peer allocation can be obtained.
				}
				
			}
		}
		else {
			System.out.println("\n !!! It is not possible to partion "+ (nodesNb-1) + " when " + byzPeersNb + " of them are potentially byzantine failed!");
		}
	}
	
	//Print the optimal committee configuration on the console
	public static void printSolutions() {
		System.out.println("\n==========================================" );
		System.out.println("========= Leader Problem Logging =========" );
		System.out.println("==========================================\n" );
		if (solved) {
			System.out.println("The minimal objective function: "+optimalObjFunc + " is obtained with "+ optm + " committees.\n" );
			System.out.println("The Committees Leaders are:\n");
			
				for (int i=0; i<optm;i++) {
					//if (optLik[i][k]>=0.999) {	System.out.println("Lik["+i+"]["+k+"]="+optLik[i][k]);
						System.out.println("In the committee" + (i+1) + ",");
						for (int j=0; j<nodesNb-1-optm;j++) {
							if ( optxij[i][j] >0) {
								System.out.println("peer" + (p[i+1].index+1) + " is the leader of peer" + (p[j+1+optm].index+1));
							}
						
						}
					//}	
				}
			
				/*for (int i=0; i<optm;i++) {
					//if (optLik[i][k]>=0.999) {	System.out.println("Lik["+i+"]["+k+"]="+optLik[i][k]);
						System.out.println("In the committee" + (i+1) + ",");
						for (int j=0; j<nodesNb-1-optm;j++) {
							if ( optxij[i][j] >0) {
								System.out.println("xij["+i+"]["+j+"]="+optxij[i][j]);
							}
						
						}
					//}	
				}*/
		}
		else {
			System.out.println("No solutions to print!");
		}
	}
	
	
	/*public static void write2File(double[][] p2pDelays, double[] failProbs, String spec) {
		
		String delaysFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + "delays_" + spec +".txt";
		String failuresFilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator + "failures_" + spec + ".txt";
		try {
			PrintWriter writerd = new PrintWriter(delaysFilePath, "UTF-8");
			PrintWriter writerf = new PrintWriter(failuresFilePath, "UTF-8");
			
			for (int i=0; i<nodesNb; i++) {
				String line_i = "";
				for (int j=0; j<nodesNb; j++) {	
					line_i = line_i + p2pDelays[i][j]+ "\t";
				}
				writerd.write(line_i + "\n");
				writerf.write(i+ "\t"+failProbs[i]+ "\n");
			}
			writerd.close();
			writerf.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}*/
	
	//Import capacity file
	public static void importcapacities(String capacityfilepath) {
		try {
			
			File filef = new File(capacityfilepath);			
			BufferedReader br = new BufferedReader(new FileReader(filef));

			String line;
			int s = 0;
	        try {
				while( ((line=br.readLine())!=null) && (s< scenarioNB))  { 
					capacity[s] = Double.parseDouble(line);
					System.out.println(capacity[s] + "\t" + s);
					s++;
					//line=br.readLine();
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//Import peers delay file
	public static void importPeersDelays(String delaysFilePath) {
		
		try {
			
			File filed = new File(delaysFilePath);			
			BufferedReader br = new BufferedReader(new FileReader(filed));

			String line;
			int i = 0;
	        try {
				while((line=br.readLine())!=null && (i<nodesNb))  { 
					//String printSTR = "";
					String[] parts = line.split("\t");
					//System.out.println(line + "\n" );
					for (int j=0; j<nodesNb; j++) {
						//System.out.println(parts[j].trim() + "\n" );
						AverageP2PDelays[i][j] = Double.parseDouble(parts[j]);
						//printSTR = printSTR + p2pDelays[i][j] + "\t";
					}
					//System.out.println(printSTR + "\n" );
					i++;
					//line=br.readLine();
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//Import peers failure rates file
	public static void importFailurerate(String failurerateFilePath) {
		try {
			
			File filef = new File(failurerateFilePath);			
			BufferedReader br = new BufferedReader(new FileReader(filef));

			String line;
			int i = 0;
	        try {
				while( ((line=br.readLine())!=null) && (i< nodesNb))  { 
					failurerate[i] = Double.parseDouble(line);
					//System.out.println(i + "\t" + failProbs[i] + "\n" );
					System.out.println(failurerate[i] + "\t" + i);
					i++;
					//line=br.readLine();
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	//Sort out out the failure rates to select the reliable peers to be potential committee leaders
	public static void sort(double[] failruerate) {
		//importfailurerate("/Users/xieyifei/eclipse-workspace/SP_ParBFT/resources/FailureRateA.txt" );
        for (int i=0; i<nodesNb; i++) {
        	p[i]=new peer();
        	p[i].fr = failurerate[i];
            p[i].index = i;
            //System.out.println(p[i].fr + "\t" + p[i].index);
        }
        
        for (int i =1; i<nodesNb; i++) {
        	for (int j =1; j<nodesNb; j++) {
        		peer temp=null;
        		if  (p[i].fr < p[j].fr) {
        			temp=p[i];
        			p[i]=p[j];
        			p[j]=temp;
        		}
        	}
        }
        
        for (int i=0; i<nodesNb; i++) {
        	System.out.println(p[i].fr + "\t" + p[i].index);
        }
	}
	
	//Import peers failure file
	public static void importPeersFailures(String failuresFilePath) {	
		try {
			
			File filef = new File(failuresFilePath);			
			BufferedReader br = new BufferedReader(new FileReader(filef));

			String line;
			int i = 0;
	        try {
				while((line=br.readLine())!=null )  { 
					String[] parts = line.split("\t");
					failProbs[i] = Double.parseDouble(parts[1].trim());
					//System.out.println(i + "\t" + failProbs[i] + "\n" );
					i++;
					//line=br.readLine();
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//Read the peer address configuration
	public static void readConfig() {
		try {
			
			File file = new File(iniConfig_FilePath);			
			BufferedReader br = new BufferedReader(new FileReader(file));

			String line;
			int i = 0;
			// VL has ID = 1
			int id = 0;//2;
	        try {
				while((line=br.readLine())!=null && !line.contains("###"))  { 
					// @<127.0.0.1:22000>=[2,CL]#
					String ip =  line.substring(line.indexOf("@")+1, line.indexOf("="));
                    String attr = line.substring(line.indexOf("=")+1, line.indexOf("#"));
                    String idStr = line.substring(line.indexOf("#")+1, line.indexOf("%"));
					String[] parts = attr.split(",");
                    if (parts[1].contains("VL")) {
                    	ID2IP.put(1,ip);
                    }
                    else {
                    	id = Integer.parseInt(idStr);
                    	ID2IP.put(id,ip);
                    	//System.out.println(id + "\t" + ip + "\n" );
                    	//id++;
                    }
					
					i++;
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//Write the optimal configuration file into .txt document 
	public static void writeConfig() {
		// iniConfig_FilePath
		String FilePath = System.getProperty("user.dir")+ File.separator +"resources" + File.separator  +  SPoutputFileName;// "intConfigOpt.txt";
		
		if (solved) {
			
			try {
				PrintWriter writerf = new PrintWriter(FilePath, "UTF-8");
				
				String line_i = "";
				
				/*for (int i : ID2IP.keySet()) {
					if(i==1) {
						line_i = "@" + ID2IP.get(1) + "=[0,VL]#\n";
						writerf.write(line_i);
					}
					else {
						for (int k=0;k<optm;k++) {
							for (int j=1; j<nodesNb;j++) {
								if (optXijk[i-1][j][k] >=0.9 && j!=(i-1)) {
									line_i = "@" + ID2IP.get(j+1) + "=[" + (k+1) + ",CF]#\n"; 
									writerf.write(line_i);
								}
								else if (optXijk[i-1][j][k] >=0.9 && j==(i-1)) {
									line_i = "@" + ID2IP.get(i) + "=[" + (k+1) + ",CL]#\n"; 
									writerf.write(line_i);
								}
								
							}
						}
					}
				
				}*/
				
				writerf.write("@" + ID2IP.get(1) + "=[0,VL]#\n");
				
				for (int i=0; i<optm; i++) {
					line_i = "@" + ID2IP.get(p[i+1].index+1) + "=[" + (i+1) + ",CL]#\n"; 
					writerf.write(line_i);
					for(int j=0; j< nodesNb-1-optm; j++) {
						if (optxij[i][j] >=0.9) {
							line_i = "@" + ID2IP.get(p[j+1+optm].index+1) + "=[" + (i+1) + ",CF]#\n"; 
							writerf.write(line_i);
						}
					}
					/*if(i==0) {
						writerf.write("###");
						writerf.write("\r\n");
						writerf.write("\r\n");
					}*/
				}
				writerf.close();
				
				/*for (int k=0;k<optm;k++) {
					for (int i=1; i<nodesNb; i++) {
						if (optXijk[i][i][k] >= 0.9) {
							line_i = "@" + ID2IP.get(i+1) + "=[" + (k+1) + ",CL]#\n"; 
							writerf.write(line_i);
						}
						for (int j=1; j<nodesNb; j++) {
							if(optXijk[i][j][k]>=0.9 && j!=i) {
							    line_i = "@" + ID2IP.get(j+1) + "=[" + (k+1) + ",CF]#\n"; 
								writerf.write(line_i);
							}
						}
					}
					if(k==0) {
						writerf.write("###");
						writerf.write("\r\n");
						writerf.write("\r\n");
					}
				}
				writerf.close();*/
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else {
			System.out.println("*initconfig* file is not updated because optimisation problem is not solved!");
		}
		
	}


}
