package SPOpt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class GenerateExp {
	
	static double x;
	static double lambda;
	static double[] failurerate;
	private static int nodesNb;
	
	public static void main (String args[]) {
		
		failurerate = new double[201];
		nodesNb = 201;
		importFailurerate("/Users/xieyifei/eclipse-workspace/SP_ParBFT/resources/FailureRate201.txt" );
		failuregeneration();
		
		Random rand = new Random();
		rand.setSeed(95);
		lambda = 0.1;
		
	}
	
	public static void importFailurerate(String failurerateFilePath) {
		try {
			
			File filef = new File(failurerateFilePath);			
			BufferedReader br = new BufferedReader(new FileReader(filef));

			String line;
			int i = 0;
	        try {
				while( (line=br.readLine())!=null )  { 
					failurerate[i] = Double.parseDouble(line);
					//System.out.println(failurerate[i] + "\t" + i);
					i++;
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void failuregeneration(){
		try {
			FileWriter out = new FileWriter(new File(System.getProperty("user.dir")+ File.separator +"resources" + File.separator  + "failures201" + ".txt"));
			int r  = 95;
			int rr = 12;
			double x =0;
			
			for(int i=0; i<nodesNb; i++) {
				double time = 0;
				for(int j=0; j<9; j++) {
					Random rand = new Random();
					rand.setSeed(r);
					x =  (Math.log(1-rand.nextDouble())/(-failurerate[i]));
					time = time + x;
					//System.out.println(time + "\t");
					out.write( (int)time +"\t");
					r = r+rr;
				}
				out.write("\r\n");
			}
			out.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
